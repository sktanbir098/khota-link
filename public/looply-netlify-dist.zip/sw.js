/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-a454db71'], (function (workbox) { 'use strict';

  importScripts("/sw-notifications.js");
  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "sw-notifications.js",
    "revision": "3f23adf08b21bc8b8b04cce704215128"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "f07f8252616c36c06ae6ba5973abacf8"
  }, {
    "url": "pwa-512x512.png",
    "revision": "76f7b9acdd8d9baa78e9398f53bb5784"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1f4cb3886db9e0039119cc44d50cb5de"
  }, {
    "url": "index.html",
    "revision": "3f795edb7eb44cd69c919af7b43c13e2"
  }, {
    "url": "icon.svg",
    "revision": "f64af07b2b49e51f415bc760f2baf7a8"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "23c7fac42c669270ab7b5be24b7318ce"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-UwOLhF7A.css",
    "revision": null
  }, {
    "url": "assets/index-DIPUGFq3.js",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_2026-11-27_at_12.27.59_AM_0cb18937.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_2026-11-23_at_11.30.43_PM_0130aa56.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_2026-11-22_at_8.12.47_PM_f67de6aa.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "23c7fac42c669270ab7b5be24b7318ce"
  }, {
    "url": "icon.svg",
    "revision": "f64af07b2b49e51f415bc760f2baf7a8"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1f4cb3886db9e0039119cc44d50cb5de"
  }, {
    "url": "pwa-512x512.png",
    "revision": "76f7b9acdd8d9baa78e9398f53bb5784"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "f07f8252616c36c06ae6ba5973abacf8"
  }, {
    "url": "sw-notifications.js",
    "revision": "3f23adf08b21bc8b8b04cce704215128"
  }, {
    "url": "manifest.webmanifest",
    "revision": "82c29c47a219cccc5c94c8e529aecba0"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html"), {
    denylist: [/^\/api\//]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.StaleWhileRevalidate({
    "cacheName": "google-fonts-stylesheets",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 2592000
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-webfonts",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 30,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
