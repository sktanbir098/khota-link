import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Loader2, Mail, Phone, Radio, Sparkles, Trash2, Video, Wifi, X } from 'lucide-react';
import { t } from '../lib/i18n';
import { AppLanguage, CallMode, ChatRoom, UserPublicProfile, UserStatus } from '../types/chat';
import { STATUS_GRADIENTS } from './StatusModal';
import { UserAvatar } from './UserAvatar';

interface Props {
  isOpen: boolean;
  lang: AppLanguage;
  chat: ChatRoom;
  displayName: string;
  peerProfile?: UserPublicProfile;
  isOnline: boolean;
  presenceLabel: string;
  peerStatuses: UserStatus[];
  onStartCall?: (mode: CallMode) => void;
  onOpenStatus: (statuses: UserStatus[], index: number) => void;
  onDeleteChat: () => Promise<void>;
  onClose: () => void;
}

export const PeerProfileModal: React.FC<Props> = ({
  isOpen,
  lang,
  chat,
  displayName,
  peerProfile,
  isOnline,
  presenceLabel,
  peerStatuses,
  onStartCall,
  onOpenStatus,
  onDeleteChat,
  onClose,
}) => {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  if (!isOpen) return null;

  const handleDeleteClick = async () => {
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    setDeleting(true);
    try {
      await onDeleteChat();
      onClose();
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 8 }}
        transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xl max-h-[90dvh] flex flex-col"
      >
        <div className="px-4 sm:px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={onClose}
              aria-label={t(lang, 'backBtn')}
              className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 shrink-0 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white truncate">
              {t(lang, 'peerProfileTitle')}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Avatar with Blinking Green Online Ring + Audio/Video Call Quick Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col items-center text-center space-y-3"
          >
            <UserAvatar
              name={displayName}
              photoUrl={peerProfile?.photoUrl}
              size="xl"
              isOnline={isOnline}
              presenceTitle={presenceLabel}
              ringColorClass="ring-white dark:ring-slate-900"
            />

            <div className="space-y-1.5">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">{displayName}</h3>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium">
                <span
                  className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-500' : 'bg-red-500'}`}
                />
                <span
                  className={
                    isOnline
                      ? 'text-emerald-700 dark:text-emerald-400'
                      : 'text-red-600 dark:text-red-400'
                  }
                >
                  {presenceLabel}
                </span>
              </div>
            </div>

            {onStartCall && peerProfile && (
              <div className="grid grid-cols-2 gap-2.5 w-full pt-1">
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.96 }}
                  onClick={() => {
                    onClose();
                    onStartCall('audio');
                  }}
                  className="min-h-[44px] px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-center gap-2 whitespace-nowrap transition-colors"
                >
                  <Phone className="w-4 h-4 shrink-0" />
                  <span>{t(lang, 'voiceCall')}</span>
                </motion.button>
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.96 }}
                  onClick={() => {
                    onClose();
                    onStartCall('video');
                  }}
                  className="min-h-[44px] px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center gap-2 whitespace-nowrap transition-colors"
                >
                  <Video className="w-4 h-4 shrink-0" />
                  <span>{t(lang, 'videoCall')}</span>
                </motion.button>
              </div>
            )}
          </motion.div>

          {/* Bio / About Card */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.22, delay: 0.04, ease: [0.16, 1, 0.3, 1] }}
            className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1"
          >
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              {t(lang, 'bioLabel')}
            </div>
            <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
              {peerProfile?.bio?.trim() ? peerProfile.bio : t(lang, 'noBioYet')}
            </p>
          </motion.div>

          {/* Connection Details */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.22, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center gap-3"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-600/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
              {chat.channel === 'gmail' ? (
                <Mail className="w-4 h-4" />
              ) : (
                <Wifi className="w-4 h-4" />
              )}
            </div>
            <div className="min-w-0">
              <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                {chat.channel === 'gmail'
                  ? 'Gmail Chat'
                  : chat.channel === 'phone'
                  ? 'Invite Code Chat'
                  : 'Nearby Direct'}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-mono-tabular truncate">
                {chat.targetHint || 'Direct Encrypted Room'}
              </div>
            </div>
          </motion.div>

          {/* Peer's Active 24h Statuses */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.22, delay: 0.12, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-2.5"
          >
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300">
              <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>{t(lang, 'activeStatuses')}</span>
            </div>

            {peerStatuses.length === 0 ? (
              <div className="p-4 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500 dark:text-slate-400">
                {t(lang, 'noActiveStatus')}
              </div>
            ) : (
              <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
                {peerStatuses.map((s, idx) => (
                  <motion.button
                    key={s.id}
                    type="button"
                    whileHover={{ scale: 1.04 }}
                    whileTap={{ scale: 0.96 }}
                    onClick={() => onOpenStatus(peerStatuses, idx)}
                    className={`relative w-24 h-32 rounded-xl overflow-hidden shrink-0 p-2 flex items-center justify-center text-center shadow-sm border border-white/15 ${
                      s.mediaType === 'image'
                        ? 'bg-black'
                        : STATUS_GRADIENTS[s.bgGradient] || STATUS_GRADIENTS.blue
                    }`}
                  >
                    {s.mediaType === 'image' && s.imageData ? (
                      <img
                        src={s.imageData}
                        alt={s.text || 'Status'}
                        referrerPolicy="no-referrer"
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-[11px] font-bold text-white line-clamp-4 leading-snug">
                        {s.text}
                      </span>
                    )}
                    <span className="absolute top-1.5 right-1.5 text-white/85">
                      <Radio className="w-3 h-3" />
                    </span>
                  </motion.button>
                ))}
              </div>
            )}
          </motion.div>

          {/* Delete Chat Danger Action */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
            {confirmDelete ? (
              <>
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  disabled={deleting}
                  className="min-h-[42px] px-4 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300"
                >
                  {t(lang, 'cancel')}
                </button>
                <button
                  type="button"
                  disabled={deleting}
                  onClick={handleDeleteClick}
                  className="flex-1 min-h-[42px] px-4 rounded-xl bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  {deleting ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4" />
                  )}
                  {deleting ? t(lang, 'deletingChat') : t(lang, 'confirmDeleteChat')}
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={handleDeleteClick}
                className="w-full min-h-[44px] px-4 rounded-xl border border-red-200 dark:border-red-900/60 bg-red-50/70 dark:bg-red-950/30 hover:bg-red-100 dark:hover:bg-red-950/50 text-red-600 dark:text-red-400 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                {t(lang, 'deleteChat')}
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};
